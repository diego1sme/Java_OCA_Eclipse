class intials{
  //Will print out my initials using my initials
  public static void main(String[]args){
    System.out.println("Lab 0 by Diego Romero"); 
    System.out.println("DD   RRR");
    System.out.println("D D  R  R");
    System.out.println("D  D RRR");
    System.out.println("D D  R R");
    System.out.println("DD   R  R");
  }
}
      
      